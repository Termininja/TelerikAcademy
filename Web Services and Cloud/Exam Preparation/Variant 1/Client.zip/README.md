Music Artists is a single page web application built with [AngularJS](http://angularjs.org/) and [Twitter Bootstrap](http://getbootstrap.com/) during the [March 2014 School Academy](http://telerikacademy.com/Courses/Courses/Details/169) meeting at [Telerik](http://www.telerik.com/). The application provides basic functionality for adding, editing, listing, searching and validating music artists and their albums. You can see a live demo at http://musicartists.herokuapp.com/. Enjoy! :)

Quick-Start:
1. Start start-server.bat
2. Start index.html