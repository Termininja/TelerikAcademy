﻿using System;

namespace Infestation
{
    public class PowerCatalyst : Catalist
    {
        // Fields
        private const int PowerEff = 3;
        private const int AggressionEff = 0;
        private const int HealthEff = 0;

        // Constructor
        public PowerCatalyst()
            : base(PowerEff, HealthEff, AggressionEff) { }

        // Method
        public override void ReactTo(ISupplement otherSupplement)
        {
            // TODO
        }
    }
}
