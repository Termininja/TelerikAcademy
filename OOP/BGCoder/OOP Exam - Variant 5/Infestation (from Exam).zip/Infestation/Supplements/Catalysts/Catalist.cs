﻿using System;

namespace Infestation
{
    public class Catalist : Supplement
    {
        // Constructor
        public Catalist(int powerEffect, int healthEffect, int aggressionEffect)
            : base(powerEffect, healthEffect, aggressionEffect) { }

        // Method
        public override void ReactTo(ISupplement otherSupplement)
        {
            // TODO
        }
    }
}
