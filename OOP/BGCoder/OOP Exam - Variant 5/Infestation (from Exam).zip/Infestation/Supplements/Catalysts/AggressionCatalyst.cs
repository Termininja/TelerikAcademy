﻿using System;

namespace Infestation
{
    public class AggressionCatalyst : Catalist
    {
        // Fields
        private const int PowerEff = 0;
        private const int AggressionEff = 3;
        private const int HealthEff = 0;

        // Constructor
        public AggressionCatalyst()
            : base(PowerEff, HealthEff, AggressionEff) { }

        // Method
        public override void ReactTo(ISupplement otherSupplement)
        {
            // TODO
        }
    }
}
