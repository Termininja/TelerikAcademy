﻿using System;

namespace Infestation
{
    public class HealthCatalyst : Catalist
    {
        // Fields
        private const int PowerEff = 0;
        private const int AggressionEff = 0;
        private const int HealthEff = 3;

        // Constructor
        public HealthCatalyst()
            : base(PowerEff, HealthEff, AggressionEff) { }

        // Method
        public override void ReactTo(ISupplement otherSupplement)
        {
            // TODO
        }
    }
}
