﻿using System;

namespace Infestation
{
    public class InfestationSpores : Supplement
    {
        // Fields
        private const int PowerEff = -1;
        private const int AggressionEff = 20;
        private const int HealthEff = 0;

        // Constructor
        public InfestationSpores()
            : base(PowerEff, HealthEff, AggressionEff) { }

        // Method
        public override void ReactTo(ISupplement otherSupplement)
        {
            throw new NotImplementedException();
        }
    }
}
