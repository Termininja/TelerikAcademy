﻿namespace Infestation
{
    public class Tank : Unit
    {
        // Fields
        public const int TankPower = 25;
        public const int TankAggression = 25;
        public const int TankHealth = 20;

        // Constructor
        public Tank(string id)
            : base(id, UnitClassification.Mechanical, Tank.TankHealth, Tank.TankPower, Tank.TankAggression) { }
    }
}
