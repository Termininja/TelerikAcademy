﻿namespace Infestation
{
    public enum UnitClassification
    {
        Biological,
        Mechanical,
        Psionic,
        Unknown
    }
}
