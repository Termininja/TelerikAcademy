﻿namespace Infestation
{
    public class Queen : Unit
    {
        // Fields
        public const int QueenPower = 1;
        public const int QueenAggression = 1;
        public const int QueenHealth = 30;

        // Constructor
        public Queen(string id)
            : base(id, UnitClassification.Psionic, Queen.QueenHealth, Queen.QueenPower, Queen.QueenAggression) { }
    }
}
