﻿namespace Infestation
{
    public class Human : Unit
    {
        // Fields
        public const int HumanPower = 4;
        public const int HumanAggression = 1;
        public const int HumanHealth = 10;

        // Constructor
        public Human(string id)
            : base(id, UnitClassification.Biological, Human.HumanHealth, Human.HumanPower, Human.HumanAggression) { }
    }
}
