﻿namespace Infestation
{
    public class Marine : Human
    {
        // Constructor
        public Marine(string id)
            : base(id)
        {
            this.AddSupplement(new WeaponrySkill());
        }
    }
}
