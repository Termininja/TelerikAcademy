﻿using System;

namespace Infestation
{
    public class WeaponrySkill : Supplement
    {
        // Fields
        private const int PowerEff = 0;
        private const int HealthEff = 0;
        private const int AggressionEff = 0;

        // Constructor
        public WeaponrySkill()
            : base(PowerEff, HealthEff, AggressionEff) { }

        // Method
        public override void ReactTo(ISupplement otherSupplement)
        {
            // TODO
        }
    }
}
